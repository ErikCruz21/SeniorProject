<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>




<!DOCTYPE html>
<html lang="en">
    <head>
     
            
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>SouthEastern Medical Group</title>

        <!-- Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,700,400italic,900,700italic,900italic' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Montserrat:400,500,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Lora:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
        
        <!-- Fontawesome -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <!-- Linearicons -->
        <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
        
        <!-- Bootstrap -->
        <link href="css/bootstrap.css" rel="stylesheet">
        
        <!-- Slick -->
        <link href="css/slick.css" rel="stylesheet">
        
        <!-- Animate -->
        <link href="css/animate.css" rel="stylesheet">
        
        <!-- Prettyphoto -->
        <link href="css/prettyPhoto.css" rel="stylesheet">
        
        <!-- Main -->
        <link href="style.css" rel="stylesheet">
        <link href="responsive.css" rel="stylesheet">
        
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="accounting-1">
        <div id="wrapper">
        <div class="page-header">
        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to SouthEastern Medical Group.</h1>
    </div>
    <p>
        <a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    </p>    
            <!-- Header -->
            <div id="header" class="wow fadeInDown">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <!-- Logo -->
                            <div class="logo">
                                <a href=""><img src="images/logo.png" alt=""></a>
                            </div>
                            <!-- End Logo -->
                            <!-- phone small -->
                            <div class="right showres">
                                <!-- Top Section -->
                                <div class="top-section">
                                    <div class="top-section-right clearfix">
                                        <div class="top-section-right-text">
                                            Absolutely Free<br/>Quotation Now
                                        </div>
                                        <div class="top-section-right-phone clearfix">
                                            <h4><img src="images/ico-phone.png" alt="" /><span>215 123 4567</span></h4>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Top Section -->
                            </div>
                            <!-- phone small -->
                            <div class="clearfix showres"></div>
                        </div>
                        <div class="col-md-8">
                            <div class="right hideres">
                                <!-- Top Section -->
                                <div class="top-section">
                                    <div class="top-section-right clearfix">
                                        <div class="top-section-right-text">
                                            Absolutely Free<br/>Quotation Now
                                        </div>
                                        <div class="top-section-right-phone clearfix">
                                            <h4><img src="images/ico-phone.png" alt="" /><span>215 123 4567</span></h4>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Top Section -->
                            </div>
                            <div class="clearfix"></div>
                            <!-- Navigation -->
                            <div class="right mainavfull">
                                <div id="main-navigation">
                                    <a href="#" id="btn-nav"><i class="fa fa-bars"></i></a>
                                    <ul class="nav-item clearfix">
                                        <li class="active">
                                            <a href="index.html">Homepages</a>
                                            <ul class="submenu">
                                                <li><a href="index.html">Accounting</a></li>
                                                <li><a href="accounting-2.html">Accounting 2</a></li>
                                                <li><a href="accounting-3.html">Accounting 3</a></li>
                                                <li><a href="architec.html">Architec</a></li>
                                                <li><a href="attorney.html">Attorney</a></li>
                                                <li><a href="barber.html">Barber</a></li>
                                                <li><a href="corporate-trainer.html">Corporate Trainer</a></li>
                                                <li><a href="mover.html">Mover</a></li>
                                                <li><a href="therapy.html">Therapy</a></li>
                                                <li><a href="trainer.html">Trainer</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="about.html">About Us</a></li>
                                        <li><a href="why-choose-us.html">Why Choose us</a></li>
                                        <li><a href="services.html">Services</a></li>
                                        <li>
                                            <a href="#">Page</a>
                                            <ul class="submenu">
                                                <li><a href="404.html">404</a></li>
                                                <li><a href="faq.html">Faq</a></li>
                                                <li><a href="portfolio.html">Portfolio 2</a></li>
                                                <li><a href="portfolio-3.html">Portfolio 3</a></li>
                                                <li><a href="gallery-3.html">Gallery 3</a></li>
                                                <li><a href="gallery-4.html">Gallery 4</a></li>
                                                <li><a href="pricing.html">Pricing</a></li>
                                                <li><a href="shortcodes.html">Shortcodes</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="blog.html">Blog</a></li>
                                        <li><a href="contact.html">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <!-- End Navigation -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Header -->
            
            <!-- Slider -->
            <div id="slider-section" class="wow fadeInUp">
                <div class="home-slider-nav clearfix">
                    <button type="button" class="home-prev slick-arrow left"><i class="fa fa-chevron-left"></i></button>
                    <button type="button" class="home-next slick-arrow right"><i class="fa fa-chevron-right"></i></button>
                </div>
                <div id="home-slider">
                    <div class="item">
                        <img src="http://placehold.it/1970x772?text=Dummy+Image" alt="" class="img-responsive" />
                        <div class="slide-desc">
                            <div class="container">
                                <div class="left">
                                    <div class="slide-desc-item">
                                        <div class="section-main-title">
                                            <i>Something about me</i>
                                            ACCOUNTING<br/>DONE<span>.</span>RIGHT<span>.</span>FAST
                                        </div>
                                        <div class="excerpt">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellent
esque dignissim eros a sapien tempus, ut eleifend neque 
convallis. Duis ac ligula nec sem fringilla. 
                                            </p>
                                        </div>
                                        <a href="" class="btn btn-more">ASK QUOTE</a><a href="" class="btn btn-bordered">ASK QUOTE</a>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <img src="http://placehold.it/1970x772?text=Dummy+Image" alt="" class="img-responsive" />
                        <div class="slide-desc">
                            <div class="container">
                                <div class="left">
                                    <div class="slide-desc-item">
                                        <div class="section-main-title">
                                            <i>Something about me</i>
                                            ACCOUNTING<br/>DONE<span>.</span>RIGHT<span>.</span>FAST
                                        </div>
                                        <div class="excerpt">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellent
esque dignissim eros a sapien tempus, ut eleifend neque 
convallis. Duis ac ligula nec sem fringilla. 
                                            </p>
                                        </div>
                                        <a href="" class="btn btn-more">ASK QUOTE</a><a href="" class="btn btn-bordered">ASK QUOTE</a>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <img src="http://placehold.it/1920x750?text=Dummy+Image" alt="" class="img-responsive" />
                        <div class="slide-desc">
                            <div class="container">
                                <div class="right">
                                    <div class="slide-desc-item">
                                        <div class="section-main-title">
                                            <i>Something about me</i>
                                            ACCOUNTING<br/>DONE<span>.</span>RIGHT<span>.</span>FAST
                                        </div>
                                        <div class="excerpt">
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellent
esque dignissim eros a sapien tempus, ut eleifend neque 
convallis. Duis ac ligula nec sem fringilla. 
                                            </p>
                                        </div>
                                        <a href="" class="btn btn-more">ASK QUOTE</a><a href="" class="btn btn-bordered">ASK QUOTE</a>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <a href="#booking-section" class="button-to-book">+</a>
                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- End Slider -->
            
            <!-- About -->
            <div id="about-section">
                <div class="container">
                    <div class="about-inner">
                        <div class="row nomarg">
                            <div class="col-md-6 col-xs-6 nopad wow fadeInLeft">
                                <div class="section-main-title">
                                    <i>Something about me</i>
                                    WELL ORGANIZED<span>.</span><br/>
                                    TRUSTED BY THOUSANDS<span>.</span>
                                </div>
                                <div class="excerpt">
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean finibus interdum urna. 
Phasellus ac lorem ut tellus ornare condimentum. Nulla facilisi. Nulla at facilisis nibh, 
in ultricies arcu. Fusce elementum mollis eros, vel ultricies enim consequat in. 
                                    </p>
                                    <p>
                                        Proin diam turpis, semper vitae libero at, pulvinar eleifend lacus. Maecenas vel nisi 
dignissim, rutrum metus sit amet, facilisis enim. Maecenas quis elit viverra eros 
congue pulvinar eu et est. Nam commodo semper nunc,
                                    </p>
                                    <div class="clearfix"></div>
                                    <div class="step">
                                        <div class="step-inner">
                                            <div class="row clearfix">
                                                <div class="col-md-4 col-xs-4 step-item">
                                                    <div class="step-ct">
                                                        <img src="images/ico-check.png" alt="">
                                                        <p>
                                                            ONTIME EVERYTIME<br/>at service
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-xs-4 step-item">
                                                    <div class="step-ct">
                                                        <img src="images/ico-pin.png" alt="">
                                                        <p>
                                                            Available at your<br/>location
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-xs-4 step-item">
                                                    <div class="step-ct">
                                                        <img src="images/ico-calendar.png" alt="">
                                                        <p>
                                                            Online booking<br/>appointment
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <a href="" class="btn btn-bordered">Read More</a>
                                
                            </div>
                            <div class="col-md-6 col-xs-6 nopad wow fadeInRight">
                                <div class="about-featured-img">
                                    <div class="row marg-10">
                                        <div class="col-md-6 col-xs-6 pad-10">
                                            <div class="about-featured-img-item">
                                                <img src="http://placehold.it/233x234?text=Dummy+Image" alt="" class="img-responsive" />
                                                <img src="http://placehold.it/233x234?text=Dummy+Image" alt="" class="img-responsive" />
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xs-6 pad-10">
                                            <div class="about-featured-img-item push-down">
                                                <img src="http://placehold.it/233x234?text=Dummy+Image" alt="" class="img-responsive" />
                                                <img src="http://placehold.it/233x234?text=Dummy+Image" alt="" class="img-responsive" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End About -->
            
            <!-- Services -->
            <div id="services-section" class="wow fadeInDown">
                <div class="row nomarg">
                    <div class="col-md-4 col-xs-4 nopad services-item">
                        <div class="services-ct">
                            <i class="lnr lnr-briefcase"></i>
                            <div class="title">
                                <i>Awesome Service</i>
                                GENERAL ACCOUNTING
                            </div>
                            <div class="services-excerpt">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing 
elit. Pellent esque dignissim eros a sapien tempus, 
ut eleifend neque convallis.
                                </p>
                            </div>
                            <a href="services-detail.html" class="btn btn-bordered">Learn More</a>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-4 nopad services-item">
                        <div class="services-ct">
                            <i class="lnr lnr-apartment"></i>
                            <div class="title">
                                <i>Awesome Service</i>
                                TAX CONSULTING
                            </div>
                            <div class="services-excerpt">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing 
elit. Pellent esque dignissim eros a sapien tempus, 
ut eleifend neque convallis.
                                </p>
                            </div>
                            <a href="services-detail.html" class="btn btn-bordered">Learn More</a>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-4 nopad services-item">
                        <div class="services-ct">
                            <i class="lnr lnr-pencil"></i>
                            <div class="title">
                                <i>Well Focused</i>
                                ADMIN SERVICES
                            </div>
                            <div class="services-excerpt">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing 
elit. Pellent esque dignissim eros a sapien tempus, 
ut eleifend neque convallis.
                                </p>
                            </div>
                            <a href="services-detail.html" class="btn btn-bordered">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Services -->

            <!-- Hblog -->
            <div id="home-blog-section" class="wow fadeInUp">
                <div class="container">
                    <div class="home-blog-inner">
                        <div class="row">
                            <div class="col-md-4 col-xs-4">
                                <div class="section-main-title">
                                    <i>Whats going on</i>
                                    LATEST NEWS & <br/>UPDATES
                                </div>
                                <div class="excerpt">
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellent esque dignissim eros a sapien tempus, ut eleifend neque convallis. 
                                    </p>
                                </div>
                                <a href="" class="btn btn-bordered">Read More</a>
                            </div>
                            <div class="col-md-4 col-xs-4">
                                <div class="home-blog-ct">
                                    <div class="home-blog-featured-images">
                                        <a href=""><img src="http://placehold.it/360x236?text=Dummy+Image" alt="" class="img-responsive"></a>
                                    </div>
                                    <div class="home-blog-title">
                                        <h5><a href="">just been moved to my new office</a></h5>
                                    </div>
                                    <div class="meta-date">
                                        Aug 12, 2015   In : <a href="">Accounting</a>
                                    </div>
                                    <a href="" class="more">READ MORE <i class="lnr lnr-arrow-right"></i></a>
                                </div>
                            </div>
                            <div class="col-md-4 col-xs-4">
                                <div class="home-blog-ct">
                                    <div class="home-blog-featured-images">
                                        <a href=""><img src="http://placehold.it/360x236?text=Dummy+Image" alt="" class="img-responsive"></a>
                                    </div>
                                    <div class="home-blog-title">
                                        <h5><a href="">just been moved to my new office</a></h5>
                                    </div>
                                    <div class="meta-date">
                                        Aug 12, 2015   In : <a href="">Accounting</a>
                                    </div>
                                    <a href="" class="more">READ MORE <i class="lnr lnr-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Hblog -->
                            
            <!-- Facts -->
            <div id="fact-section" class="wow fadeInDown">
                <div class="container">
                    <div class="fact-inner">
                        <div class="text-center">
                            <div class="section-main-title">
                                <i>Some Cool Facts</i>
                                WHY YOU SHOULD CHOOSE ME
                            </div>
                            <div class="excerpt">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellent esque dignissim eros a sapien tempus, ut eleifend neque 
convallis. Duis ac ligula nec sem fringilla. Mauris lacinia augue sagittis dolor.
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 col-xs-4 fact-item">
                                <div class="fact-ct">
                                    <i class="lnr lnr-clock"></i>
                                    <h4>HARD WORKING<span>.</span><br/>& ALWAYS ON TIME<span>.</span></h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adi
elit. Pellent esque dignissim eros a sapien ut eleifend neque convallis.</p>
                                </div>
                            </div>
                            <div class="col-md-4 col-xs-4 fact-item">
                                <div class="fact-ct">
                                    <i class="lnr lnr-thumbs-up"></i>
                                    <h4>Satisfaction<br/>Guaranteed always<span>.</span></h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adi
elit. Pellent esque dignissim eros a sapien ut eleifend neque convallis.</p>
                                </div>
                            </div>
                            <div class="col-md-4 col-xs-4 fact-item">
                                <div class="fact-ct">
                                    <i class="lnr lnr-pie-chart"></i>
                                    <h4>INternational<span>.</span><br/>& local accounting<span>.</span></h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adi
elit. Pellent esque dignissim eros a sapien ut eleifend neque convallis.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Facts -->
            
            <!-- Testimonial -->
            <div id="testimonial-section" class="wow fadeInUp">
                
                <div class="container">
                    <div class="row nomarg">
                        <div class="col-md-8 col-xs-8 nopad">
                            <div class="testimonial-wrap">
                                <div class="testimonial-inner">
                                    <div class="testimonial-to-right">
                                        <div class="section-main-title">
                                            <i>Testimonials</i>
                                            WHAT PEOPLE SAY
                                        </div>
                                        <div class="testimonial-nav">
                                            <button type="button" class="slick-prev"><i class="lnr lnr-arrow-left"></i></button>
                                            <button type="button" class="slick-next"><i class="lnr lnr-arrow-right"></i></button>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div id="testimonial-slider">

                                            <div class="testimonial-item">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dapibus tortor. 
            Suspendisse orci ante, vestibulum at libero ac, vulputate vulputate sem. Cras quis 
                                                    lorem condimentum, ornare mi molestie, rhoncus ipsum.</p>
                                                <div class="clearfix"></div>
                                                <div class="testimonial-name">
                                                    <div class="left">
                                                        <img src="http://placehold.it/67x66?text=Dummy+Image" alt="" class="img-responsive">
                                                    </div>
                                                    <div class="left name">
                                                        JAMES ANDERSON
                                                        <span>Founder of Theme Designer</span>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                            <div class="testimonial-item">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dapibus tortor. 
            Suspendisse orci ante, vestibulum at libero.</p>
                                                <div class="clearfix"></div>
                                                <div class="testimonial-name">
                                                    <div class="left">
                                                        <img src="http://placehold.it/67x66?text=Dummy+Image" alt="" class="img-responsive">
                                                    </div>
                                                    <div class="left name">
                                                        JAMES ANDERSON
                                                        <span>Founder of Theme Designer</span>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="interest">
                                    <div class="testimonial-to-right">
                                        <div class="interest-item">
                                            <div class="left">
                                                <div class="int-img">
                                                    <img src="images/int-1.png" alt=""/>
                                                </div>
                                            </div>
                                            <div class="left">
                                                <div class="section-main-title">
                                                    <a href="">
                                                        <i>Awesome Features</i>
                                                        GREAT! I WANT TO BUY BOOK ME NOW <span class="lnr lnr-arrow-right"></span>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-xs-4 nopad">
                            <div class="form-request">
                                <div class="testimonial-inner">
                                    <div class="section-main-title">
                                        <i>Free Estimation</i>
                                        REQUEST A QUOTE
                                    </div>
                                    <form>
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="fname" placeholder="Full Name / Company Name">
                                        </div>
                                        <div class="form-group">
                                            <input type="email" class="form-control" id="femail" placeholder="Email Address">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="fnumb" placeholder="Phone Number">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="emp" placeholder="Number of Employees">
                                        </div>
                                        <div class="form-group">
                                            <select class="form-control">
                                                <option>Vat Complaince</option>
                                                <option>Vat Complaince 2</option>
                                                <option>Vat Complaince 3</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="inv" placeholder="Number of Incoming Invoices">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="invo" placeholder="Number of Outgoing Invoices">
                                        </div>
                                        <button type="submit" class="btn btn-submit">GET A QUOTE</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Testimonial -->
            
            <!-- Afterbout -->
            <div id="afterbout-section" class="wow fadeInDown">
                <div class="container">
                    <div class="afterbout-inner">
                        <div class="text-center">
                            <div class="section-main-title">
                                <i>Something About Me</i>
                                WELL ORGANIZED<span>.</span> TRUSTED BY THOUSANDS<span>.</span>
                            </div>
                            <div class="excerpt">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellent esque dignissim eros a sapien tempus, ut eleifend neque 
convallis. Duis ac ligula nec sem fringilla. Mauris lacinia augue sagittis dolor.
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 col-xs-4 afterbout-item">
                                <div class="afterbout-icon">
                                    <i class="lnr lnr-history"></i>
                                </div>
                                <h4>ON TIME EVERYTIME</h4>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing 
elit. Pellent esque dignissim eros a sapien tempus, 
ut eleifend neque convallis.
                                </p>
                            </div>
                            <div class="col-md-4 col-xs-4 afterbout-item">
                                <div class="afterbout-icon">
                                    <i class="lnr lnr-earth"></i>
                                </div>
                                <h4>AVAILABLE AT YOUR LOCATION</h4>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing 
elit. Pellent esque dignissim eros a sapien tempus, 
ut eleifend neque convallis.
                                </p>
                            </div>
                            <div class="col-md-4 col-xs-4 afterbout-item">
                                <div class="afterbout-icon">
                                    <i class="lnr lnr-calendar-full"></i>
                                </div>
                                <h4>ON TIME EVERYTIME</h4>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing 
elit. Pellent esque dignissim eros a sapien tempus, 
ut eleifend neque convallis.
                                </p>
                            </div>
                        </div>
                        <div class="text-center">
                            <a href="" class="btn btn-more">LEARN MORE</a><a href="" class="btn btn-bordered">BOOK NOW</a>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- End Afterbout -->
            
            <!-- Client -->
            <div id="client-section" class="wow fadeInUp">
                <div class="container">
                    <div class="client-inner">
                        <div class="text-center">
                            <div class="section-main-title">
                                <i>Awesome Clients</i>
                                SOME OF COOL CLIENTS
                            </div>
                            <div class="excerpt">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellent esque dignissim eros a sapien tempus, ut eleifend neque 
convallis. Duis ac ligula nec sem fringilla. Mauris lacinia augue sagittis dolor.
                                </p>
                            </div>
                        </div>
                        <div class="row client nomarg clearfix">
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-1.png" alt="" /></a>
                            </div>
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-2.png" alt="" /></a>
                            </div>
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-3.png" alt="" /></a>
                            </div>
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-4.png" alt="" /></a>
                            </div>
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-5.png" alt="" /></a>
                            </div>
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-6.png" alt="" /></a>
                            </div>
                        </div>
                        <div class="row client nomarg clearfix">
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-7.png" alt="" /></a>
                            </div>
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-8.png" alt="" /></a>
                            </div>
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-6.png" alt="" /></a>
                            </div>
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-3.png" alt="" /></a>
                            </div>
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-1.png" alt="" /></a>
                            </div>
                            <div class="col-md-2 col-xs-4 client-item nopad">
                                <a href=""><img src="images/c-4.png" alt="" /></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Client -->
            
            <!-- Book -->
            <div id="booking-section" class="wow fadeInDown">
                <div class="container">
                    <div class="booking-inner">
                        <div class="row">
                            <div class="col-md-6 col-xs-6">
                                <div class="text-section">
                                    <div class="section-main-title">
                                        <i>Satisfied?</i>
                                        AWESOME<span>.</span><br/>BOOK ME NOW<span>.</span>
                                    </div>
                                    <div class="excerpt">
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellent esque dignissim eros a sapien tempus, ut eleifend neque 
convallis. Duis ac ligula nec sem fringilla. Mauris lacinia augue sagittis dolor.
                                        </p>
                                    </div>
                                </div>
                                <div class="featured">
                                    <h5>I am featured on</h5>
                                    <div class="row">
                                        <div class="col-md-3 col-xs-6">
                                            <img src="images/fton-1.png" alt="" />
                                        </div>
                                        <div class="col-md-3 col-xs-6">
                                            <img src="images/fton-1.png" alt="" />
                                        </div>
                                        <div class="col-md-3 col-xs-6">
                                            <img src="images/fton-1.png" alt="" />
                                        </div>
                                        <div class="col-md-3 col-xs-6">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-6 calendar">
                                <img src="images/cal-1.png" alt="" class="img-responsive">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Book -->
            
            <!-- Footer -->
            <div id="footer-section" class="wow fadeInUp">
                <div class="container">
                    <div class="footer-inner">
                        <div class="row">
                            <div class="col-md-2 col-xs-12">
                                <div class="ft-logo">
                                    <img src="images/logo.png" alt="" />
                                </div>
                                <div class="ft-text">
                                    <p>
                                        Copyright 2015.<br/>All Rights Reserved.
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-5 col-xs-6">
                                <ul class="ft-menu clearfix">
                                    <li><a href="">HOME</a></li>
                                    <li><a href="">WHY me</a></li>
                                    <li><a href="">accounting</a></li>
                                    <li><a href="">About me</a></li>
                                    <li><a href="">Features</a></li>
                                    <li><a href="">tax consulting</a></li>
                                    <li><a href="">services</a></li>
                                    <li><a href="">Gallery</a></li>
                                    <li><a href="">Page</a></li>
                                    <li><a href="">Contact Us</a></li>
                                    <li><a href="">salary management</a></li>
                                </ul>
                            </div>
                            <div class="col-md-5 col-xs-6">
                                <div class="map-wrap left">
                                    <div id="map"></div>
                                </div>
                                <div class="ft-contact left">
                                    <div class="name">JOHNATHAN DOE</div>
                                    <p>Address will be appear here, some text will here, City, State, Country</p>
                                    <div class="call">Call Me : <a href="">+215 123 4567</a></div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Footer -->
            <div id="mmap" class="hide"></div>
                    
        </div>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>
        <!-- map -->
        <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
        <script src="js/map.min.js"></script>
        <!-- Slick -->
        <script src="js/slick.js"></script>
        <!-- Animation -->
        <script src="js/wow.min.js"></script>
        <!-- Prettyphoto -->
        <script src="js/jquery.prettyPhoto.js"></script>
        <!-- counter -->
        <script src="js/waypoint.js"></script>
        <script src="js/counterup.js"></script>
        <!-- Themescript -->
        <script src="js/theme-script.js"></script>
    </body>
</html>